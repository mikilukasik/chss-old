import { sampleRequestHandler } from "./sampleSocket/sampleRequestHandler";

export const initRoutes = ({ msg }) => {
  const sampleSocket = msg.ws("/sampleSocket");
  sampleSocket.on(...sampleRequestHandler);
};
