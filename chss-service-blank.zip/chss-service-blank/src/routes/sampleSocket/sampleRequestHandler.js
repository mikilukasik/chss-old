export const sampleRequestHandler = [
  "sampleCommand",
  async (data, comms) => {
    console.log(data);
    comms.send("OK");
  },
];
